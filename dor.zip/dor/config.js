const AUTH = 'https://tdwidm.telkomsel.com';

const API = 'https://tdw.telkomsel.com';

const AUTH_CLIENT = 'eyJuYW1lIjoiYXV0aDAuanMiLCJ2ZXJzaW9uIjoiNi44LjQifQ';

const CLIENT_ID = 'TFKYtPumTXcLM8xEZATlvceX2Vtblaw3';

const CHANNELID = 'UX';

const APP_VERSION = '4.5.0';

const BASE_URL = 'https://ibeng.herokuapp.com/';

module.exports = {
  AUTH,
  API,
  AUTH_CLIENT,
  CHANNELID,
  CLIENT_ID,
  APP_VERSION,
  BASE_URL
};
